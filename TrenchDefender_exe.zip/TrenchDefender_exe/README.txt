Trench Defender by Tim Godwin. 

Run TrenchDefender.exe with TrenchDefender_Data in the same location. Checking 'Windowed' box during setup is recommended.

OBJECTIVE:
Shoot and destroy enemy tanks to increase your score. Survive as long as possible. Enemies that get past your defense will subtract from your score.

CONTROLS:
A and D or LeftArrowKey and RightArrowKey to move Left/Right.
SpaceBar to fire when gun is ready.

EXTRA:
After each completed wave, additional enemies will spawn. Your tank will also be upgraded in 1 of 3 categories. Make it to wave 9 to see all upgrades!


