Simple game of Rock-Scissors-Paper (a.k.a. Paper-Scissors-Rock (a.k.a. Rock-Paper-Scissors)).

Played against computer opponent who picks with an RNG.

You must open selection.html in Firefox to begin; other browsers are not guaranteed to work.

Thanks for playing!  
